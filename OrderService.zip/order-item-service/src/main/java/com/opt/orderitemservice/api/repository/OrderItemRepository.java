package com.opt.orderitemservice.api.repository;

import com.opt.orderitemservice.api.entity.OrderItem;

import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderItemRepository extends JpaRepository<OrderItem, Integer> {
}
