package com.opt.orderitemservice.api.controller;

import com.opt.orderitemservice.api.entity.OrderItem;
import com.opt.orderitemservice.api.service.OrderItemService;
import com.sun.jdi.request.InvalidRequestStateException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/orderItem")
public class OrderItemController {

    @Autowired
    private OrderItemService orderItemService;

    @PostMapping("/createItemOrder" )
    public OrderItem createItemOrder(@RequestBody OrderItem order) {
        return orderItemService.saveOrder(order);
    }
}
