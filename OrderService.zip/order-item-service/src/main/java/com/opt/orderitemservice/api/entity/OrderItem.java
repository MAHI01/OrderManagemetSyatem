package com.opt.orderitemservice.api.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ORDER_ITEM_TB")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderItem {

    @Id
    private int productCode;
    private String productName;
    private int quantity;

}
