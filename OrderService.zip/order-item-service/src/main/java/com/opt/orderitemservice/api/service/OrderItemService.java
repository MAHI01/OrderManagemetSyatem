package com.opt.orderitemservice.api.service;

import com.opt.orderitemservice.api.entity.OrderItem;
import com.opt.orderitemservice.api.repository.OrderItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderItemService<OrderRepository> {

    @Autowired
    private OrderItemRepository orderItemRepository;

    public OrderItem saveOrder(OrderItem order){

        return orderItemRepository.save(order);
    }

}
