package com.opt.orderservice.api.controller;

import com.opt.orderservice.api.entity.Order;
import com.opt.orderservice.api.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    @PostMapping("/createOrder")
    public Order createOrder(@RequestBody Order order){
        return orderService.saveOrder(order);
    }

}
